package com.aditya.jarvispro;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private TextView status, transcript;
    private HudView hud;
    private boolean listening = false;
    private static final int AUDIO_PERMISSION = 41;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildUi();
        tts = new TextToSpeech(this, result -> { if (result == TextToSpeech.SUCCESS) tts.setLanguage(Locale.US); });
        if (SpeechRecognizer.isRecognitionAvailable(this)) recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setPadding(24, 20, 24, 24); root.setBackgroundColor(Color.rgb(3,5,7));
        TextView brand = new TextView(this); brand.setText("J.A.R.V.I.S."); brand.setTextColor(Color.rgb(255,174,76)); brand.setTextSize(24); brand.setLetterSpacing(.28f); brand.setGravity(Gravity.CENTER);
        TextView sub = new TextView(this); sub.setText("PERSONAL INTELLIGENCE SYSTEM  •  PROTOTYPE"); sub.setTextColor(Color.rgb(129,145,155)); sub.setTextSize(9); sub.setGravity(Gravity.CENTER); sub.setLetterSpacing(.12f);
        hud = new HudView(this); LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, 0, 1f); hp.topMargin=12; hp.bottomMargin=8;
        status = new TextView(this); status.setText("STANDBY"); status.setTextColor(Color.rgb(255,175,77)); status.setTextSize(15); status.setGravity(Gravity.CENTER); status.setLetterSpacing(.24f);
        transcript = new TextView(this); transcript.setText("Awaiting your command"); transcript.setTextColor(Color.LTGRAY); transcript.setTextSize(14); transcript.setGravity(Gravity.CENTER); transcript.setMinHeight(48);
        Button mic = new Button(this); mic.setText("START VOICE SESSION"); mic.setAllCaps(false); mic.setTextColor(Color.BLACK); mic.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(255,164,58))); mic.setOnClickListener(v -> startListening());
        TextView note = new TextView(this); note.setText("MICROPHONE IS ACTIVE ONLY DURING A SESSION YOU START"); note.setTextColor(Color.rgb(110,124,134)); note.setTextSize(9); note.setGravity(Gravity.CENTER); note.setPadding(0,12,0,0);
        root.addView(brand); root.addView(sub); root.addView(hud,hp); root.addView(status); root.addView(transcript); root.addView(mic); root.addView(note); setContentView(root);
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION); return; }
        if (recognizer == null) { say("Speech recognition is not available on this device."); return; }
        listening = true; status.setText("LISTENING"); hud.setActive(true);
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN"); intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) { status.setText("LISTENING"); }
            public void onBeginningOfSpeech() { status.setText("HEARING YOU"); }
            public void onRmsChanged(float rms) { hud.setLevel(rms); }
            public void onBufferReceived(byte[] b) {} public void onEndOfSpeech() { status.setText("THINKING"); }
            public void onError(int e) { listening=false; hud.setActive(false); status.setText("STANDBY"); transcript.setText("Voice session ended. Tap to try again."); }
            public void onResults(Bundle b) { listening=false; hud.setActive(false); ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(r!=null&&!r.isEmpty()) handleCommand(r.get(0)); else status.setText("STANDBY"); }
            public void onPartialResults(Bundle b) {} public void onEvent(int t, Bundle b) {}
        });
        recognizer.startListening(intent);
    }

    private void handleCommand(String raw) {
        String c=raw.toLowerCase(Locale.ROOT).trim(); transcript.setText("“"+raw+"”");
        if (c.contains("hey jarvis")) c=c.replace("hey jarvis", "").trim();
        if (c.contains("open youtube")) { openUrl("https://www.youtube.com"); respond("Opening YouTube."); }
        else if (c.contains("open whatsapp")) { launchPackage("com.whatsapp"); respond("Opening WhatsApp. Please review messages before sending."); }
        else if (c.contains("time")) { String time=java.text.DateFormat.getTimeInstance().format(new java.util.Date()); respond("The time is "+time); }
        else if (c.contains("stop") || c.contains("standby")) { respond("Returning to standby."); }
        else { respond("I heard you. This prototype currently supports a few basic commands. More integrations need to be added and tested."); }
    }
    private void respond(String s) { status.setText("SPEAKING"); say(s); status.postDelayed(() -> status.setText("STANDBY"), 1800); transcript.setText(s); }
    private void say(String s) { if (tts!=null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply"); }
    private void openUrl(String url) { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(ActivityNotFoundException e) { Toast.makeText(this,"No app available",Toast.LENGTH_SHORT).show(); } }
    private void launchPackage(String pkg) { Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i!=null) startActivity(i); else Toast.makeText(this,"App not found",Toast.LENGTH_SHORT).show(); }
    @Override protected void onDestroy() { if(recognizer!=null) recognizer.destroy(); if(tts!=null) tts.shutdown(); super.onDestroy(); }
}
