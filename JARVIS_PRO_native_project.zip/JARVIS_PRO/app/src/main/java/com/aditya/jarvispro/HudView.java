package com.aditya.jarvispro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class HudView extends View {
    private final Paint p=new Paint(3); private boolean active=false; private float level=0; private long start=System.currentTimeMillis();
    public HudView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void setActive(boolean a){active=a;invalidate();} public void setLevel(float l){level=Math.max(0,l);invalidate();}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2,cy=h/2;float r=Math.min(w,h)*.36f; long t=System.currentTimeMillis()-start; c.drawColor(0xFF030507);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.2f);p.setColor(0x553C83A0);c.drawCircle(cx,cy,r*1.55f,p);p.setColor(0x8876B9D0);c.drawCircle(cx,cy,r*1.25f,p);
        p.setColor(0xFFFF9A32);p.setStrokeWidth(2.2f);c.drawArc(new RectF(cx-r*1.4f,cy-r*1.4f,cx+r*1.4f,cy+r*1.4f),(t/35f)%360,active?230:150,false,p);
        p.setColor(0xFFFFC06B);p.setStrokeWidth(1.4f);for(int i=0;i<72;i++){double a=Math.PI*2*i/72;float in=r*(1.18f+(i%6==0?.09f:0));float out=r*(1.25f+(i%6==0?.18f:.04f));c.drawLine(cx+(float)Math.cos(a)*in,cy+(float)Math.sin(a)*in,cx+(float)Math.cos(a)*out,cy+(float)Math.sin(a)*out,p);}
        p.setStyle(Paint.Style.FILL);p.setColor(0x22FF8C24);p.setShadowLayer(38,0,0,0xFFFF8A20);c.drawCircle(cx,cy,r*.55f,p);p.clearShadowLayer();p.setColor(0xFFFFB24D);c.drawCircle(cx,cy,r*.23f,p);p.setColor(0xFFFFE1A8);c.drawCircle(cx,cy,r*.09f,p);
        p.setColor(0xFFFFB45A);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(Math.max(12,r*.13f));c.drawText(active?"VOICE LINK ACTIVE":"JARVIS CORE",cx,cy+r*1.85f,p);
        p.setColor(0xAA54A6C3);p.setTextSize(9);c.drawText("SYSTEM  •  SECURE CHANNEL  •  READY",cx,cy-r*1.78f,p);
        if(active){postInvalidateDelayed(40);} }
}
