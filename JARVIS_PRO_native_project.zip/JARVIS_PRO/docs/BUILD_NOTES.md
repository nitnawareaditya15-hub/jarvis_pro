# Build notes
- Android Gradle Plugin: 8.7.3
- Gradle: use a compatible Gradle 8.9 distribution.
- JDK: 17
- Android SDK: compile/target 35
- No API key is included.
- The project has not been compiled or device-tested in this environment.
