# J.A.R.V.I.S. PRO — Native Android starter project

**Package:** `com.aditya.jarvispro`  
**Target:** Android 15 / API 35, minimum Android 8.0 (API 26)  
**Design:** hybrid amber + electric-blue HUD inspired by the supplied reference image.

## Open the project
1. Install Android Studio on a computer (or use a compatible Android IDE that supports Gradle Android projects).
2. Open this `JARVIS_PRO` folder as an existing Gradle project.
3. Let Gradle sync. Use JDK 17 and Android SDK Platform 35.
4. Connect your phone with USB debugging enabled, or use Build > Build APK(s).

## What this starter currently contains
- Native Java Android application shell.
- Animated hybrid-colour HUD screen.
- Text-to-speech replies using the device's installed voice engine.
- Microphone permission flow and a user-started speech-recognition session.
- Basic demo commands: open YouTube, open WhatsApp, tell the time, standby.
- The supplied reference image in `docs/reference-interface.jpg`.

## Important: this is a starter, not the complete requested assistant
This project is **not yet a finished Jarvis replacement**. The current speech session starts when the user taps the button. It does not provide a persistent “Hey Jarvis” wake word while the app is closed, reliable 2–3 metre detection, six bundled premium voices, WhatsApp message sending, call answering, hotspot/brightness/volume control, second-phone control, or money transfers.

Those require separate Android components, device/OEM testing, permissions, secure pairing, and—in some cases—special Android roles or user confirmation. Android restricts background microphone use; a wake-word service must be explicitly enabled and shown with a persistent notification. Do not promise always-on listening until it has been implemented and tested on the target Vivo phone.

## Security design requirements for later phases
- Never put an OpenAI API key in the APK. Use a secure backend or a user-supplied key stored with appropriate protection.
- Never speak, log, or store a PIN as plain text. Use Android BiometricPrompt / device credential authentication.
- Require explicit confirmation for calls, messages, and every financial transaction. Display recipient and amount before any payment handoff; do not automate payment approval.
- Pair the second phone using a one-time pairing code and authenticated encrypted communication. Require approval on the second phone for sensitive actions.
- Use only official Android APIs and user-granted permissions; no hidden control or bypassing device security.

## Next development milestones
1. Implement a proper foreground wake-word service using a supported on-device keyword engine, with a visible notification and battery controls.
2. Add command routing and language selection (English, Hindi, Marathi).
3. Add user-approved integrations for calls, messaging, and device settings.
4. Add secure second-device pairing and biometric confirmation flows.
5. Add a backend AI connector with rate limits and protected credentials.

## Voice selection note
The six names Atlas, Orion, Neo, Athena, Nova, and Echo are proposed presets, not bundled recordings. Actual voice availability depends on the installed Android TTS engines and their language/voice packs.
